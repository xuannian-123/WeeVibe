#!/usr/bin/env python3
"""Offline package-entry verification; no WeChat UI, login, DB or network calls."""
from __future__ import annotations
import argparse
import json
import re
import stat
import tempfile
import zipfile
from pathlib import Path


class PackageError(Exception):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PackageError(message)


def read_json(path: Path) -> dict:
    require(path.is_file(), f"Missing JSON: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, UnicodeError) as error:
        raise PackageError(f"Invalid JSON: {path}") from error
    require(isinstance(value, dict), f"Expected JSON object: {path}")
    return value


def inside(base: Path, relative: str, label: str) -> Path:
    require(isinstance(relative, str) and bool(relative), f"Missing {label}")
    require(not Path(relative).is_absolute(), f"Absolute {label} forbidden")
    result = (base / relative).resolve()
    require(result == base or base in result.parents, f"{label} escapes its root")
    return result


def resolve_resource(mini: Path, owner: Path, value: str) -> Path | None:
    if "{{" in value or value.startswith(("data:", "https:", "http:", "plugin:", "dynamicLib:")):
        return None
    clean = value.split("?", 1)[0].split("#", 1)[0]
    result = (mini / clean.lstrip("/") if clean.startswith("/") else owner.parent / clean).resolve()
    require(result == mini or mini in result.parents, f"Resource escapes mini root: {value}")
    return result


def verify(root: Path) -> dict:
    root = root.resolve()
    config = read_json(root / "project.config.json")
    require(config.get("compileType") == "miniprogram", "compileType must be miniprogram")
    require(config.get("setting", {}).get("urlCheck") is True, "urlCheck must remain true")
    mini = inside(root, config.get("miniprogramRoot", ""), "miniprogramRoot")
    expected = root / "project/apps/miniprogram/dist"
    require(mini == expected.resolve(), "Root must point at project/apps/miniprogram/dist")
    app = read_json(mini / "app.json")
    for required in ["app.js", "app.wxss", "runtime.js", "vendors.js", "taro.js", "common.js", "assets/share-safe.png"]:
        require((mini / required).is_file(), f"Missing app/runtime asset: {required}")
    pages = app.get("pages", [])
    require(isinstance(pages, list) and len(pages) == 5, "Expected five current application pages")
    for package in app.get("subPackages", app.get("subpackages", [])):
        pages += [package["root"].rstrip("/") + "/" + page for page in package["pages"]]
    for page in pages:
        base = inside(mini, page, "page")
        for suffix in [".js", ".json", ".wxml"]:
            require(Path(str(base) + suffix).is_file(), f"Missing page file: {page}{suffix}")
    component_bases: set[Path] = set()
    for file in mini.rglob("*.json"):
        data = read_json(file)
        components = data.get("usingComponents", {})
        require(isinstance(components, dict), f"Invalid usingComponents: {file}")
        for value in components.values():
            require(isinstance(value, str), "Component path must be text")
            target = resolve_resource(mini, file, value)
            if target is not None:
                component_bases.add(target)
    if app.get("tabBar", {}).get("custom") is True:
        component_bases.add(mini / "custom-tab-bar/index")
    for base in component_bases:
        for suffix in [".js", ".json", ".wxml"]:
            require(Path(str(base) + suffix).is_file(), f"Missing component: {base.relative_to(mini)}{suffix}")
    static_refs = 0
    for file in list(mini.rglob("*.wxml")) + list(mini.rglob("*.wxss")):
        text = file.read_text(encoding="utf-8")
        refs = re.findall(r"(?:src\s*=\s*[\"']|@import\s*[\"'])([^\"']+)", text)
        refs += re.findall(r"url\(\s*[\"']?([^\"')\s]+)", text)
        for value in refs:
            target = resolve_resource(mini, file, value)
            if target is not None:
                require(target.is_file(), f"Missing referenced asset: {file.relative_to(mini)} -> {value}")
                static_refs += 1
    # All supported import entries must resolve the same app, without changing source layout.
    for folder in [root / "project/apps/miniprogram", mini]:
        nested = read_json(folder / "project.config.json")
        target = inside(folder.resolve(), nested.get("miniprogramRoot", ""), "nested miniprogramRoot")
        require(target == mini, f"Nested import root mismatch: {folder}")
    require(not (root / "WeeVibe").exists(), "Obsolete extra WeeVibe wrapper remains")
    require((root / "导入说明.md").is_file(), "Missing top-level import instructions")
    return {"status": "passed", "root_config": "project.config.json", "miniprogram_root": "project/apps/miniprogram/dist/", "pages": len(pages), "components": len(component_bases), "static_resource_references": static_refs, "dist_files": sum(p.is_file() for p in mini.rglob("*")), "custom_tab_bar": app.get("tabBar", {}).get("custom") is True, "wechat_devtools": "not_run", "wechat_device": "not_run", "backend_connectivity": "not_run"}


def verify_zip(archive: Path) -> dict:
    with tempfile.TemporaryDirectory(prefix="weevibe-fresh-extract-") as directory:
        root = Path(directory)
        with zipfile.ZipFile(archive) as zipped:
            require(zipped.testzip() is None, "ZIP CRC verification failed")
            for item in zipped.infolist():
                inside(root, item.filename, "ZIP entry")
                require(not stat.S_ISLNK(item.external_attr >> 16), "ZIP symlinks forbidden")
            zipped.extractall(root)
        result = verify(root)
        result["fresh_extraction"] = True
        return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--zip", type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(verify_zip(args.zip) if args.zip else verify(args.root), ensure_ascii=False, indent=2))
    except (PackageError, OSError, zipfile.BadZipFile) as error:
        print(json.dumps({"status": "failed", "reason": str(error)}, ensure_ascii=False))
        raise SystemExit(1)

#!/usr/bin/env python3
"""Regression checks for package import roots. Writes only temporary extraction copies."""
import argparse
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from verify_package_import import PackageError, verify, verify_zip

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('archive', type=Path)
parser.add_argument('--previous', type=Path)
args, extra = parser.parse_known_args()

class ImportPackageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='weevibe-import-regression-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        with zipfile.ZipFile(args.archive) as archive:
            archive.extractall(self.root)
        self.mini = self.root / 'project/apps/miniprogram/dist'

    def change(self, path, mutation):
        value=json.loads(path.read_text());mutation(value);path.write_text(json.dumps(value))

    def rejected(self, substring):
        with self.assertRaisesRegex(PackageError, substring):verify(self.root)

    def test_fresh_extract_import_entry_and_all_resources(self):
        result=verify_zip(args.archive)
        self.assertEqual(result['pages'],5)
        self.assertEqual(result['components'],1)
        self.assertEqual(result['dist_files'],36)
        self.assertTrue(result['fresh_extraction'])
        self.assertEqual(result['wechat_devtools'],'not_run')

    def test_missing_root_config_is_rejected(self):
        (self.root/'project.config.json').unlink();self.rejected('Missing JSON')

    def test_missing_miniprogram_root_is_rejected(self):
        self.change(self.root/'project.config.json',lambda x:x.pop('miniprogramRoot'));self.rejected('Missing miniprogramRoot')

    def test_old_wrapper_path_is_rejected(self):
        self.change(self.root/'project.config.json',lambda x:x.update(miniprogramRoot='WeeVibe/project/apps/miniprogram/dist/'));self.rejected('Root must point')

    def test_missing_page_javascript_is_rejected(self):
        (self.mini/'pages/requirements/index.js').unlink();self.rejected('Missing page file')

    def test_missing_shared_component_is_rejected(self):
        (self.mini/'comp.wxml').unlink();self.rejected('Missing component')

    def test_missing_wxml_import_is_rejected(self):
        (self.mini/'base.wxml').unlink();self.rejected('Missing referenced asset')

    def test_missing_image_asset_is_rejected(self):
        (self.mini/'assets/share-safe.png').unlink();self.rejected('Missing app/runtime asset')

    def test_declared_custom_tab_bar_must_exist(self):
        self.change(self.mini/'app.json',lambda x:x.update(tabBar={'custom':True}));self.rejected('Missing component')

    def test_root_must_not_escape_extraction(self):
        self.change(self.root/'project.config.json',lambda x:x.update(miniprogramRoot='../outside'));self.rejected('escapes its root')

    def test_url_check_is_not_disabled(self):
        self.change(self.root/'project.config.json',lambda x:x['setting'].update(urlCheck=False));self.rejected('urlCheck must remain true')

if args.previous:
    try:verify_zip(args.previous)
    except PackageError as error:print('CONFIRMED previous package rejected at outer import root:',str(error).split('/project.config.json')[0])
    else:raise SystemExit('Previous package unexpectedly passes: reproduction evidence invalid')
unittest.main(argv=['test_package_import.py',*extra],verbosity=2)

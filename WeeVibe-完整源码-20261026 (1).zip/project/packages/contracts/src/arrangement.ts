import { z } from 'zod';
import { activityIdSchema, activitySegmentTypeSchema, activityLocationSchema, activityFeeSchema, idempotencyKeySchema } from './activities';
const version = z.number().int().min(1).max(2_147_483_647);
const instant = z.iso.datetime({ offset: true }).transform(value => new Date(value).toISOString());
const digest = z.string().regex(/^[a-f0-9]{64}$/);

/** Public agreed segment data only; never a DB row or a private requirement answer. */
export const arrangementPlanSchema = z.object({
  segment_id: activityIdSchema, client_ref: z.string().min(1).max(64).regex(/^[A-Za-z0-9_-]+$/),
  position: z.number().int().min(0).max(2_147_483_647), type: activitySegmentTypeSchema,
  name: z.string().min(1).max(100), starts_at: instant, ends_at: instant, deadline_at: instant,
  minimum_participants: version, capacity: version, location: activityLocationSchema,
  fee: activityFeeSchema, requirements: z.string().max(1000)
}).strict().superRefine((plan, ctx) => {
  if (plan.minimum_participants > plan.capacity) ctx.addIssue({ code: 'custom', message: '最低人数不能超过上限' });
  if (Date.parse(plan.starts_at) >= Date.parse(plan.ends_at) || Date.parse(plan.deadline_at) > Date.parse(plan.starts_at)) ctx.addIssue({ code: 'custom', message: '安排时间无效' });
});
export type ArrangementPlan = z.infer<typeof arrangementPlanSchema>;

/** Consumable server event format. This slice deliberately exposes NO change writer. */
export const arrangementChangeEventSchema = z.object({
  schema_version: z.literal(1), segment_id: activityIdSchema,
  from_plan_revision: version, to_plan_revision: version,
  before: arrangementPlanSchema, after: arrangementPlanSchema
}).strict().superRefine((event, ctx) => {
  if (event.to_plan_revision !== event.from_plan_revision + 1 || event.before.segment_id !== event.segment_id || event.after.segment_id !== event.segment_id) ctx.addIssue({ code: 'custom', message: '变更版本或目标无效' });
  const { minimum_participants: beforeMinimum, ...before } = event.before;
  const { minimum_participants: afterMinimum, ...after } = event.after;
  // Schema parsing fixes property order before comparison; only minimum may differ.
  if (beforeMinimum === afterMinimum || JSON.stringify(before) !== JSON.stringify(after)) ctx.addIssue({ code: 'custom', message: '本片仅识别最低人数实质变化历史' });
});
export type ArrangementChangeEvent = z.infer<typeof arrangementChangeEventSchema>;
export const ARRANGEMENT_CHANGE_EVENT_TYPE = 'segment_arrangement_changed';
export const ARRANGEMENT_HISTORY_LIMIT = 500;
const changeSchema = z.object({
  from_plan_revision: version, to_plan_revision: version, changed_at: instant,
  before: arrangementPlanSchema, after: arrangementPlanSchema
}).strict();
export const arrangementReviewSchema = z.object({
  activity_id: activityIdSchema, segment_id: activityIdSchema, viewer_user_id: activityIdSchema,
  revision: version, current_plan_revision: version, accepted_plan_revision: version.nullable(), server_time: instant,
  state: z.enum(['up_to_date', 'ready', 'unavailable']), can_reaccept: z.boolean(),
  reason: z.enum(['UP_TO_DATE', 'HISTORY_UNAVAILABLE', 'CANCELLED', 'SEGMENT_STARTED']).nullable(),
  current_plan: arrangementPlanSchema, accepted_plan: arrangementPlanSchema.nullable(),
  history_digest: digest.nullable(), changes: z.array(changeSchema).max(ARRANGEMENT_HISTORY_LIMIT)
}).strict().superRefine((review, ctx) => {
  const invalid = () => ctx.addIssue({ code: 'custom', message: '安排差异响应不一致' });
  if (review.current_plan.segment_id !== review.segment_id) invalid();
  if (review.state === 'unavailable') {
    if (review.can_reaccept || review.reason !== 'HISTORY_UNAVAILABLE' || review.history_digest !== null || review.accepted_plan !== null || review.changes.length) invalid();
  } else if (review.state === 'up_to_date') {
    if (review.accepted_plan_revision !== review.current_plan_revision || review.can_reaccept || review.reason !== 'UP_TO_DATE' || review.history_digest !== null || review.changes.length || JSON.stringify(review.accepted_plan) !== JSON.stringify(review.current_plan)) invalid();
  } else {
    if (review.accepted_plan_revision === null || review.accepted_plan_revision >= review.current_plan_revision || !review.accepted_plan || !review.history_digest || !review.changes.length || review.can_reaccept !== (review.reason === null) || (review.reason !== null && review.reason !== 'CANCELLED' && review.reason !== 'SEGMENT_STARTED')) invalid();
    let previous = review.accepted_plan, revision = review.accepted_plan_revision;
    for (const change of review.changes) {
      const event = arrangementChangeEventSchema.safeParse({ schema_version: 1, segment_id: review.segment_id, from_plan_revision: change.from_plan_revision, to_plan_revision: change.to_plan_revision, before: change.before, after: change.after });
      if (change.from_plan_revision !== revision || !event.success) invalid();
      if (JSON.stringify(previous) !== JSON.stringify(change.before)) invalid();
      previous = change.after; revision = change.to_plan_revision;
    }
    if (revision !== review.current_plan_revision || JSON.stringify(previous) !== JSON.stringify(review.current_plan)) invalid();
  }
});
export type ArrangementReview = z.infer<typeof arrangementReviewSchema>;
export const reacceptArrangementCommandSchema = z.object({
  action: z.literal('reaccept'), idempotency_key: idempotencyKeySchema,
  expected_revision: version, expected_plan_revision: version,
  from_accepted_plan_revision: version, history_digest: digest
}).strict();
export type ReacceptArrangementCommand = z.infer<typeof reacceptArrangementCommandSchema>;

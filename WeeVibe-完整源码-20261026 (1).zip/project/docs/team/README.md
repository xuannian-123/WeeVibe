# 团队开发入口

WeeVibe采用单个Taro微信小程序、Next.js Node API、PostgreSQL/Prisma与共享Zod契约。管理者与参与者共用客户端，业务身份与管理权限分开。

使用Codex的成员先拉取最新代码，再从仓库目录启动新对话，确认已加载根目录[AGENTS.md](../../AGENTS.md)。已有对话请明确要求“重新阅读AGENTS.md，概括当前分支、预览方式与合并/部署边界后再开始”。默认在自己的功能分支开发和预览、提交PR，由维护者统一合并和更新共享版本。

- [品牌、微信账号名与兼容标识](./branding.md)
- [工程、目录、Markdown及对话名称同步检查](./rename-audit.md)
- [克隆、配置与本地开发](./development.md)
- [成员首次开发条件预检](./development-preflight.md)
- [当前架构、已验证内容及后续接通](./architecture.md)
- [团队接手边界、轻量简版和待办](./handoff.md)
- [功能认领、代码分区与界面一致性方案](./collaboration.md)
- [共享界面与交互规范](./frontend-guide.md)
- [12张任务的代码入口与修改边界](./task-map.md)
- [后续改进、子任务与新增任务怎样归类](./task-workflow.md)
- [双微信实际验收步骤与记录](./two-wechat-acceptance.md)
- [创建失败与原请求恢复](./create-recovery.md)
- [完整业务规则](../11-首版成局加入与补位规则.md)
- [创建/申请/审批正式接口](../engineering/07-第二轮业务接口交接.md)
- [小程序简版页面交接](../product/05-第二轮小程序页面实施交接.md)

## 五人按功能自主认领

仓库[12张功能任务](https://github.com/xuannian-123/WeeVibe/issues)由成员自行认领，一张任务约定一位牵头人，可邀请协助，不预先固定五个岗位。依赖表示整体验收需要接通，不妨碍先按共享契约实现页面或规则。

认领任务 → 对齐接口与文件归属 → 从最新main创建功能分支 → 提交PR → 复核和接入 → 真实验收 → 关闭Issue。共享契约、根配置、锁文件与迁移同时修改前先协调，避免覆盖。

| 任务 | 范围 |
|---|---|
| [WG-01](https://github.com/xuannian-123/WeeVibe/issues/1) | 工程、微信身份和部署接通 |
| [WG-02](https://github.com/xuannian-123/WeeVibe/issues/2) | 多环节创建、地点填写 |
| [WG-03](https://github.com/xuannian-123/WeeVibe/issues/3) | 邀请、报名、整体审批与名单 |
| [WG-04](https://github.com/xuannian-123/WeeVibe/issues/4) | 成局、退出、原安排补位 |
| [WG-05](https://github.com/xuannian-123/WeeVibe/issues/5) | 发布后变更、保位及重新接受 |
| [WG-06](https://github.com/xuannian-123/WeeVibe/issues/6) | 管理权转让 |
| [WG-07](https://github.com/xuannian-123/WeeVibe/issues/7) | AI创建、邀请及时间协调 |
| [WG-08](https://github.com/xuannian-123/WeeVibe/issues/8) | 图片分享卡 |
| [WG-09](https://github.com/xuannian-123/WeeVibe/issues/9) | 应用内待办 |
| [WG-10](https://github.com/xuannian-123/WeeVibe/issues/10) | 再约新活动 |
| [WG-11](https://github.com/xuannian-123/WeeVibe/issues/11) | 联调及赛前验收 |
| [WG-12](https://github.com/xuannian-123/WeeVibe/issues/12) | 现场正式界面和试用改进 |

已有源码、离线通过、真实本机PG通过、云端通过与真机通过分别记录。当前Issue开放不表示没有代码，也不能因编译通过就关闭任务。

2026-10-25用户最终明确项目及小程序内部品牌为WeeVibe，微信账号名另外申请，不能把界面名称修改当作微信账号已改名。账号名具体状态见[名称说明](./branding.md)。付费、旧Secret重置、体验版替换或正式发布仍按各自授权边界执行。

import { createHash } from 'node:crypto';
import { ARRANGEMENT_CHANGE_EVENT_TYPE, ARRANGEMENT_HISTORY_LIMIT, arrangementChangeEventSchema, arrangementPlanSchema, type ArrangementPlan, type ArrangementReview } from '@weevibe/contracts';
import type { loadActivity, Tx } from './state';
type ActivityState = Awaited<ReturnType<typeof loadActivity>>;
export type ArrangementSegment = ActivityState['segments'][number];
export function arrangementPlan(segment: ArrangementSegment): ArrangementPlan {
  return arrangementPlanSchema.parse({
    segment_id: segment.id, client_ref: segment.clientRef, position: segment.position, type: segment.type, name: segment.name,
    starts_at: segment.startsAt.toISOString(), ends_at: segment.endsAt.toISOString(), deadline_at: segment.deadlineAt.toISOString(),
    minimum_participants: segment.minimumParticipants, capacity: segment.capacity,
    location: segment.location, fee: segment.fee, requirements: segment.requirements
  });
}
type CompleteHistory = { accepted: ArrangementPlan; changes: ArrangementReview['changes']; digest: string };
/** Reject gaps/forks/unknown schemas instead of inventing historical promises from today's plan. */
export async function arrangementHistory(tx: Tx, activity: ActivityState, segment: ArrangementSegment, actorId: string, from: number | null, current: ArrangementPlan): Promise<CompleteHistory | null> {
  if (from === null || from < 1 || from >= segment.planRevision || segment.planRevision - from > ARRANGEMENT_HISTORY_LIMIT) return null;
  const rows = await tx.activityEvent.findMany({
    where: { activityId: activity.id, type: ARRANGEMENT_CHANGE_EVENT_TYPE, detail: { path: ['segment_id'], equals: segment.id } },
    orderBy: [{ revision: 'asc' }, { id: 'asc' }], take: ARRANGEMENT_HISTORY_LIMIT + 1,
    select: { activityId: true, revision: true, detail: true, createdAt: true }
  });
  if (rows.length > ARRANGEMENT_HISTORY_LIMIT) return null;
  const parsed = [];
  for (const row of rows) {
    const event = arrangementChangeEventSchema.safeParse(row.detail);
    if (!event.success || row.activityId !== activity.id || event.data.segment_id !== segment.id || !Number.isSafeInteger(row.revision) || row.revision < 1 || row.revision > activity.revision || !Number.isFinite(row.createdAt.getTime())) return null;
    // A fork may lie outside the requested start, but no accepted history may be in the future.
    if (event.data.to_plan_revision > segment.planRevision) return null;
    if (event.data.from_plan_revision >= from) parsed.push({ event: event.data, revision: row.revision, at: row.createdAt.toISOString() });
  }
  parsed.sort((a, b) => a.event.from_plan_revision - b.event.from_plan_revision);
  if (parsed.length !== segment.planRevision - from) return null;
  let revision = from, priorActivityRevision = 0;
  let previous: ArrangementPlan | null = null;
  const changes: ArrangementReview['changes'] = [];
  for (const row of parsed) {
    const e = row.event;
    if (e.from_plan_revision !== revision || row.revision <= priorActivityRevision || previous && JSON.stringify(previous) !== JSON.stringify(e.before)) return null;
    changes.push({ from_plan_revision: e.from_plan_revision, to_plan_revision: e.to_plan_revision, changed_at: row.at, before: e.before, after: e.after });
    revision = e.to_plan_revision; previous = e.after; priorActivityRevision = row.revision;
  }
  if (!previous || revision !== segment.planRevision || JSON.stringify(previous) !== JSON.stringify(current)) return null;
  const digest = createHash('sha256').update(JSON.stringify({ activity_id: activity.id, segment_id: segment.id, actor_id: actorId, from, to: segment.planRevision, current, chain: parsed })).digest('hex');
  return { accepted: changes[0].before, changes, digest };
}
